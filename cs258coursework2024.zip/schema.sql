/*Put your CREATE TABLE statements (and any other schema related definitions) here*/
